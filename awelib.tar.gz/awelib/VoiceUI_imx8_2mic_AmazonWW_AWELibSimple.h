/****************************************************************************
 *
 *		Target Tuning Symbol File
 *		-------------------------
 *
 * 		This file is populated with symbol information only for modules
 *		that have the 'isTunable' property checked in the .awd.
 *
 *          Generated on:  16-May-2018 15:02:49
 *
 ***************************************************************************/

#ifndef VOICEUI_IMX8_2MIC_AVS_V3B_1MB_SENSORY_AWELIBSIMPLE_H
#define VOICEUI_IMX8_2MIC_AVS_V3B_1MB_SENSORY_AWELIBSIMPLE_H

// ----------------------------------------------------------------------
// InputMeter [Meter]
// Peak and RMS meter module

#define AWE_InputMeter_ID 30000

// int meterType - Operating mode of the meter. Selects between peak and 
//         RMS calculations. See the discussion section for more details.
// Default value: 18
// Range: unrestricted
#define AWE_InputMeter_meterType_OFFSET 8
#define AWE_InputMeter_meterType_MASK 0x00000100
#define AWE_InputMeter_meterType_SIZE -1

// float attackTime - Attack time of the meter. Specifies how quickly 
//         the meter value rises.
#define AWE_InputMeter_attackTime_OFFSET 9
#define AWE_InputMeter_attackTime_MASK 0x00000200
#define AWE_InputMeter_attackTime_SIZE -1

// float releaseTime - Release time of the meter. Specifies how quickly 
//         the meter decays.
#define AWE_InputMeter_releaseTime_OFFSET 10
#define AWE_InputMeter_releaseTime_MASK 0x00000400
#define AWE_InputMeter_releaseTime_SIZE -1

// float attackCoeff - Internal coefficient that realizes the attack 
//         time.
#define AWE_InputMeter_attackCoeff_OFFSET 11
#define AWE_InputMeter_attackCoeff_MASK 0x00000800
#define AWE_InputMeter_attackCoeff_SIZE -1

// float releaseCoeff - Internal coefficient that realizes the release 
//         time.
#define AWE_InputMeter_releaseCoeff_OFFSET 12
#define AWE_InputMeter_releaseCoeff_MASK 0x00001000
#define AWE_InputMeter_releaseCoeff_SIZE -1

// float value[4] - Array of meter output values, one per channel.
#define AWE_InputMeter_value_OFFSET 13
#define AWE_InputMeter_value_MASK 0x00002000
#define AWE_InputMeter_value_SIZE 4


// ----------------------------------------------------------------------
// SpeakerProcessing.MasterVolume1 [ScalerV2]
// General purpose scaler with a single gain

#define AWE_SpeakerProcessing____MasterVolume1_ID 30045

// float gain - Gain in either linear or dB units.
// Default value: 15
// Range: -40 to 24
#define AWE_SpeakerProcessing____MasterVolume1_gain_OFFSET 8
#define AWE_SpeakerProcessing____MasterVolume1_gain_MASK 0x00000100
#define AWE_SpeakerProcessing____MasterVolume1_gain_SIZE -1

// float smoothingTime - Time constant of the smoothing process (0 = 
//         unsmoothed).
// Default value: 10
// Range: 0 to 1000
#define AWE_SpeakerProcessing____MasterVolume1_smoothingTime_OFFSET 9
#define AWE_SpeakerProcessing____MasterVolume1_smoothingTime_MASK 0x00000200
#define AWE_SpeakerProcessing____MasterVolume1_smoothingTime_SIZE -1

// int isDB - Selects between linear (=0) and dB (=1) operation
// Default value: 1
// Range: 0 to 1
#define AWE_SpeakerProcessing____MasterVolume1_isDB_OFFSET 10
#define AWE_SpeakerProcessing____MasterVolume1_isDB_MASK 0x00000400
#define AWE_SpeakerProcessing____MasterVolume1_isDB_SIZE -1

// float targetGain - Target gain in linear units.
#define AWE_SpeakerProcessing____MasterVolume1_targetGain_OFFSET 11
#define AWE_SpeakerProcessing____MasterVolume1_targetGain_MASK 0x00000800
#define AWE_SpeakerProcessing____MasterVolume1_targetGain_SIZE -1

// float currentGain - Instantaneous gain applied by the module.
#define AWE_SpeakerProcessing____MasterVolume1_currentGain_OFFSET 12
#define AWE_SpeakerProcessing____MasterVolume1_currentGain_MASK 0x00001000
#define AWE_SpeakerProcessing____MasterVolume1_currentGain_SIZE -1

// float smoothingCoeff - Smoothing coefficient.
#define AWE_SpeakerProcessing____MasterVolume1_smoothingCoeff_OFFSET 13
#define AWE_SpeakerProcessing____MasterVolume1_smoothingCoeff_MASK 0x00002000
#define AWE_SpeakerProcessing____MasterVolume1_smoothingCoeff_SIZE -1


// ----------------------------------------------------------------------
// SpeakerProcessing.ParametricEQ [BiquadCascade]
// Cascade of second order Biquad filters

#define AWE_SpeakerProcessing____ParametricEQ_ID 30018

// int numStages - Number of stages in the filter. The filter order = 
//         2*numStages.
#define AWE_SpeakerProcessing____ParametricEQ_numStages_OFFSET 8
#define AWE_SpeakerProcessing____ParametricEQ_numStages_MASK 0x00000100
#define AWE_SpeakerProcessing____ParametricEQ_numStages_SIZE -1

// float coeffs[50] - Matrix of filter coefficients. The size of the 
//         matrix is 5 x numStages. Each column contains the variables for a 
//         biquad arranged as [b0; b1; b2; a1; a2].
// Default value:
//     0.99469     0.99469      0.5643      1.5451     0.98491      1.0347      1.0049      1.0298       1.222      1.0008
//     -1.9894     -1.9894     -1.1129     -2.2154     -1.8242     -1.9134      -1.841     -1.4104    -0.43383     -1.9794
//     0.99469     0.99469     0.54884     0.86826     0.84934     0.92706     0.95738      0.8681     0.45415     0.98232
//     -1.9893     -1.9893     -1.9792     -1.2796     -1.8219     -1.9134      -1.841     -1.4104    -0.43383     -1.9794
//     0.98942     0.98942     0.97939     0.47759     0.83653      0.9618     0.96227     0.89795     0.67619     0.98314
// Range: unrestricted
#define AWE_SpeakerProcessing____ParametricEQ_coeffs_OFFSET 9
#define AWE_SpeakerProcessing____ParametricEQ_coeffs_MASK 0x00000200
#define AWE_SpeakerProcessing____ParametricEQ_coeffs_SIZE 50

// float state[20] - State variables. 2 per channel.
#define AWE_SpeakerProcessing____ParametricEQ_state_OFFSET 10
#define AWE_SpeakerProcessing____ParametricEQ_state_MASK 0x00000400
#define AWE_SpeakerProcessing____ParametricEQ_state_SIZE 20


// ----------------------------------------------------------------------
// SpeakerProcessing.speakerLimiterCore [AGCLimiterCore]
// Gain computer used to realize soft-knee peak limiters

#define AWE_SpeakerProcessing____speakerLimiterCore_ID 30024

// float threshold - Amplitude level at which the AGC Limiter Core 
//         reduces its output gain value
// Default value: -20
// Range: -60 to 0.  Step size = 0.1
#define AWE_SpeakerProcessing____speakerLimiterCore_threshold_OFFSET 8
#define AWE_SpeakerProcessing____speakerLimiterCore_threshold_MASK 0x00000100
#define AWE_SpeakerProcessing____speakerLimiterCore_threshold_SIZE -1

// float gain - Value used to scale the output of the AGC Limiter Core
// Default value: 0
// Range: -20 to 20.  Step size = 0.1
#define AWE_SpeakerProcessing____speakerLimiterCore_gain_OFFSET 9
#define AWE_SpeakerProcessing____speakerLimiterCore_gain_MASK 0x00000200
#define AWE_SpeakerProcessing____speakerLimiterCore_gain_SIZE -1

// float slope - Internal derived variable which holds the slope of the 
//         compression curve
#define AWE_SpeakerProcessing____speakerLimiterCore_slope_OFFSET 10
#define AWE_SpeakerProcessing____speakerLimiterCore_slope_MASK 0x00000400
#define AWE_SpeakerProcessing____speakerLimiterCore_slope_SIZE -1

// float kneeDepth - Knee depth controls the sharpness of the transition 
//         between no limiting and limiting
// Default value: 0.1
// Range: 0.1 to 60
#define AWE_SpeakerProcessing____speakerLimiterCore_kneeDepth_OFFSET 11
#define AWE_SpeakerProcessing____speakerLimiterCore_kneeDepth_MASK 0x00000800
#define AWE_SpeakerProcessing____speakerLimiterCore_kneeDepth_SIZE -1

// float ratio - Slope of the output attenuation when the signal is 
//         above threshold - derived from the standard compression ratio 
//         parameter by the formula slope = 1.0 - (1.0/ratio)
// Default value: 100
// Range: 0.1 to 100
#define AWE_SpeakerProcessing____speakerLimiterCore_ratio_OFFSET 12
#define AWE_SpeakerProcessing____speakerLimiterCore_ratio_MASK 0x00001000
#define AWE_SpeakerProcessing____speakerLimiterCore_ratio_SIZE -1

// float attackTime - Envelope detector attack time constant
// Default value: 0.5
// Range: 0.01 to 1000
#define AWE_SpeakerProcessing____speakerLimiterCore_attackTime_OFFSET 13
#define AWE_SpeakerProcessing____speakerLimiterCore_attackTime_MASK 0x00002000
#define AWE_SpeakerProcessing____speakerLimiterCore_attackTime_SIZE -1

// float decayTime - Envelope detector decay time constant
// Default value: 200
// Range: 0.01 to 1000
#define AWE_SpeakerProcessing____speakerLimiterCore_decayTime_OFFSET 14
#define AWE_SpeakerProcessing____speakerLimiterCore_decayTime_MASK 0x00004000
#define AWE_SpeakerProcessing____speakerLimiterCore_decayTime_SIZE -1

// float currentGain - Instantaneous gain computed by the block
#define AWE_SpeakerProcessing____speakerLimiterCore_currentGain_OFFSET 15
#define AWE_SpeakerProcessing____speakerLimiterCore_currentGain_MASK 0x00008000
#define AWE_SpeakerProcessing____speakerLimiterCore_currentGain_SIZE -1

// float sharpnessFactor - Internal derived variable which is used to 
//         implement the soft knee
#define AWE_SpeakerProcessing____speakerLimiterCore_sharpnessFactor_OFFSET 16
#define AWE_SpeakerProcessing____speakerLimiterCore_sharpnessFactor_MASK 0x00010000
#define AWE_SpeakerProcessing____speakerLimiterCore_sharpnessFactor_SIZE -1

// float attackCoeff - Internal derived variable which implements the 
//         attackTime
#define AWE_SpeakerProcessing____speakerLimiterCore_attackCoeff_OFFSET 17
#define AWE_SpeakerProcessing____speakerLimiterCore_attackCoeff_MASK 0x00020000
#define AWE_SpeakerProcessing____speakerLimiterCore_attackCoeff_SIZE -1

// float decayCoeff - Internal derived variable which implements the 
//         decayTime
#define AWE_SpeakerProcessing____speakerLimiterCore_decayCoeff_OFFSET 18
#define AWE_SpeakerProcessing____speakerLimiterCore_decayCoeff_MASK 0x00040000
#define AWE_SpeakerProcessing____speakerLimiterCore_decayCoeff_SIZE -1

// float envState - Holds the instantaneous state of the envelope 
//         detector
#define AWE_SpeakerProcessing____speakerLimiterCore_envState_OFFSET 19
#define AWE_SpeakerProcessing____speakerLimiterCore_envState_MASK 0x00080000
#define AWE_SpeakerProcessing____speakerLimiterCore_envState_SIZE -1


// ----------------------------------------------------------------------
// SpeakerProcessing.SoftClip1 [SoftClip]
// Soft clip in float32

#define AWE_SpeakerProcessing____SoftClip1_ID 30041

// float threshold - Transition point between linear response and knee.
// Default value: -0.3
// Range: -20 to 0
#define AWE_SpeakerProcessing____SoftClip1_threshold_OFFSET 8
#define AWE_SpeakerProcessing____SoftClip1_threshold_MASK 0x00000100
#define AWE_SpeakerProcessing____SoftClip1_threshold_SIZE -1

// float th - Threshold in linear scale
#define AWE_SpeakerProcessing____SoftClip1_th_OFFSET 9
#define AWE_SpeakerProcessing____SoftClip1_th_MASK 0x00000200
#define AWE_SpeakerProcessing____SoftClip1_th_SIZE -1

// float lastIn[1] - Array of last input sample, one per channel.
#define AWE_SpeakerProcessing____SoftClip1_lastIn_OFFSET 10
#define AWE_SpeakerProcessing____SoftClip1_lastIn_MASK 0x00000400
#define AWE_SpeakerProcessing____SoftClip1_lastIn_SIZE 1

// float lastOut[1] - Array of last output sample, one per channel.
#define AWE_SpeakerProcessing____SoftClip1_lastOut_OFFSET 11
#define AWE_SpeakerProcessing____SoftClip1_lastOut_MASK 0x00000800
#define AWE_SpeakerProcessing____SoftClip1_lastOut_SIZE 1

// float currentGain[1] - Array of soft clipper gain, one per channel.
#define AWE_SpeakerProcessing____SoftClip1_currentGain_OFFSET 12
#define AWE_SpeakerProcessing____SoftClip1_currentGain_MASK 0x00001000
#define AWE_SpeakerProcessing____SoftClip1_currentGain_SIZE 1


// ----------------------------------------------------------------------
// LatencyControlSamps [Delay]
// Time delay in which the delay is specified in samples

#define AWE_LatencyControlSamps_ID 30001

// int maxDelay - Maximum delay, in samples. The size of the delay 
//         buffer is (maxDelay+1)*numChannels.
#define AWE_LatencyControlSamps_maxDelay_OFFSET 8
#define AWE_LatencyControlSamps_maxDelay_MASK 0x00000100
#define AWE_LatencyControlSamps_maxDelay_SIZE -1

// int currentDelay - Current delay.
// Default value: 400
// Range: 0 to 6400.  Step size = 1
#define AWE_LatencyControlSamps_currentDelay_OFFSET 9
#define AWE_LatencyControlSamps_currentDelay_MASK 0x00000200
#define AWE_LatencyControlSamps_currentDelay_SIZE -1

// int stateIndex - Index of the oldest state variable in the array of 
//         state variables.
#define AWE_LatencyControlSamps_stateIndex_OFFSET 10
#define AWE_LatencyControlSamps_stateIndex_MASK 0x00000400
#define AWE_LatencyControlSamps_stateIndex_SIZE -1

// int stateHeap - Heap in which to allocate memory.
#define AWE_LatencyControlSamps_stateHeap_OFFSET 11
#define AWE_LatencyControlSamps_stateHeap_MASK 0x00000800
#define AWE_LatencyControlSamps_stateHeap_SIZE -1

// float state[6658] - State variable array.
#define AWE_LatencyControlSamps_state_OFFSET 12
#define AWE_LatencyControlSamps_state_MASK 0x00001000
#define AWE_LatencyControlSamps_state_SIZE 6658


// ----------------------------------------------------------------------
// FreqDomainProcessing.NoiseReductionDB [Sink]
// Copies the data at the input pin and stores it in an internal buffer.

#define AWE_FreqDomainProcessing____NoiseReductionDB_ID 30010

// int enable - To enable or disable the plotting.
// Default value: 0
// Range: unrestricted
#define AWE_FreqDomainProcessing____NoiseReductionDB_enable_OFFSET 8
#define AWE_FreqDomainProcessing____NoiseReductionDB_enable_MASK 0x00000100
#define AWE_FreqDomainProcessing____NoiseReductionDB_enable_SIZE -1

// float value[1] - Captured values.
#define AWE_FreqDomainProcessing____NoiseReductionDB_value_OFFSET 9
#define AWE_FreqDomainProcessing____NoiseReductionDB_value_MASK 0x00000200
#define AWE_FreqDomainProcessing____NoiseReductionDB_value_SIZE 1

// float yRange[2] - Y-axis range.
// Default value:
//     -5  5
// Range: unrestricted
#define AWE_FreqDomainProcessing____NoiseReductionDB_yRange_OFFSET 10
#define AWE_FreqDomainProcessing____NoiseReductionDB_yRange_MASK 0x00000400
#define AWE_FreqDomainProcessing____NoiseReductionDB_yRange_SIZE 2


// ----------------------------------------------------------------------
// FreqDomainProcessing.AEC_Perf_Sink [Sink]
// Copies the data at the input pin and stores it in an internal buffer.

#define AWE_FreqDomainProcessing____AEC_Perf_Sink_ID 30014

// int enable - To enable or disable the plotting.
// Default value: 0
// Range: unrestricted
#define AWE_FreqDomainProcessing____AEC_Perf_Sink_enable_OFFSET 8
#define AWE_FreqDomainProcessing____AEC_Perf_Sink_enable_MASK 0x00000100
#define AWE_FreqDomainProcessing____AEC_Perf_Sink_enable_SIZE -1

// float value[1250] - Captured values.
#define AWE_FreqDomainProcessing____AEC_Perf_Sink_value_OFFSET 9
#define AWE_FreqDomainProcessing____AEC_Perf_Sink_value_MASK 0x00000200
#define AWE_FreqDomainProcessing____AEC_Perf_Sink_value_SIZE 1250

// float yRange[2] - Y-axis range.
// Default value:
//     -5  5
// Range: unrestricted
#define AWE_FreqDomainProcessing____AEC_Perf_Sink_yRange_OFFSET 10
#define AWE_FreqDomainProcessing____AEC_Perf_Sink_yRange_MASK 0x00000400
#define AWE_FreqDomainProcessing____AEC_Perf_Sink_yRange_SIZE 2


// ----------------------------------------------------------------------
// FreqDomainProcessing.Direction [SinkInt]
// Copies the data at the input pin and stores it in an internal buffer

#define AWE_FreqDomainProcessing____Direction_ID 30009

// int value[1] - Captured values
#define AWE_FreqDomainProcessing____Direction_value_OFFSET 8
#define AWE_FreqDomainProcessing____Direction_value_MASK 0x00000100
#define AWE_FreqDomainProcessing____Direction_value_SIZE 1


// ----------------------------------------------------------------------
// WakeWordProcessing1.TriggerStorage [TriggeredSink]
// Copies the data at the input pin and stores it in an internal buffer. 
// When triggered, buffer is frozen.

#define AWE_WakeWordProcessing1____TriggerStorage_ID 31000

// int reset - Data will remain latched until reset set to 1.
#define AWE_WakeWordProcessing1____TriggerStorage_reset_OFFSET 8
#define AWE_WakeWordProcessing1____TriggerStorage_reset_MASK 0x00000100
#define AWE_WakeWordProcessing1____TriggerStorage_reset_SIZE -1

// int ctrl_index - Index of first non-zero element of the ctrl signal. 
//         Any non-zero element will trigger a data acquisition.
#define AWE_WakeWordProcessing1____TriggerStorage_ctrl_index_OFFSET 9
#define AWE_WakeWordProcessing1____TriggerStorage_ctrl_index_MASK 0x00000200
#define AWE_WakeWordProcessing1____TriggerStorage_ctrl_index_SIZE -1

// int manual_trigger - Trigger data acquisition from Matlab
#define AWE_WakeWordProcessing1____TriggerStorage_manual_trigger_OFFSET 10
#define AWE_WakeWordProcessing1____TriggerStorage_manual_trigger_MASK 0x00000400
#define AWE_WakeWordProcessing1____TriggerStorage_manual_trigger_SIZE -1

// float value[16000] - Captured values.
#define AWE_WakeWordProcessing1____TriggerStorage_value_OFFSET 11
#define AWE_WakeWordProcessing1____TriggerStorage_value_MASK 0x00000800
#define AWE_WakeWordProcessing1____TriggerStorage_value_SIZE 16000


// ----------------------------------------------------------------------
// endIndex [SinkInt]
// Copies the data at the input pin and stores it in an internal buffer

#define AWE_endIndex_ID 30012

// int value[1] - Captured values
#define AWE_endIndex_value_OFFSET 8
#define AWE_endIndex_value_MASK 0x00000100
#define AWE_endIndex_value_SIZE 1


// ----------------------------------------------------------------------
// OutputMeter [Meter]
// Peak and RMS meter module

#define AWE_OutputMeter_ID 30005

// int meterType - Operating mode of the meter. Selects between peak and 
//         RMS calculations. See the discussion section for more details.
// Default value: 18
// Range: unrestricted
#define AWE_OutputMeter_meterType_OFFSET 8
#define AWE_OutputMeter_meterType_MASK 0x00000100
#define AWE_OutputMeter_meterType_SIZE -1

// float attackTime - Attack time of the meter. Specifies how quickly 
//         the meter value rises.
#define AWE_OutputMeter_attackTime_OFFSET 9
#define AWE_OutputMeter_attackTime_MASK 0x00000200
#define AWE_OutputMeter_attackTime_SIZE -1

// float releaseTime - Release time of the meter. Specifies how quickly 
//         the meter decays.
#define AWE_OutputMeter_releaseTime_OFFSET 10
#define AWE_OutputMeter_releaseTime_MASK 0x00000400
#define AWE_OutputMeter_releaseTime_SIZE -1

// float attackCoeff - Internal coefficient that realizes the attack 
//         time.
#define AWE_OutputMeter_attackCoeff_OFFSET 11
#define AWE_OutputMeter_attackCoeff_MASK 0x00000800
#define AWE_OutputMeter_attackCoeff_SIZE -1

// float releaseCoeff - Internal coefficient that realizes the release 
//         time.
#define AWE_OutputMeter_releaseCoeff_OFFSET 12
#define AWE_OutputMeter_releaseCoeff_MASK 0x00001000
#define AWE_OutputMeter_releaseCoeff_SIZE -1

// float value[3] - Array of meter output values, one per channel.
#define AWE_OutputMeter_value_OFFSET 13
#define AWE_OutputMeter_value_MASK 0x00002000
#define AWE_OutputMeter_value_SIZE 3


// ----------------------------------------------------------------------
// isTriggered [SinkInt]
// Copies the data at the input pin and stores it in an internal buffer

#define AWE_isTriggered_ID 30003

// int value[1] - Captured values
#define AWE_isTriggered_value_OFFSET 8
#define AWE_isTriggered_value_MASK 0x00000100
#define AWE_isTriggered_value_SIZE 1


// ----------------------------------------------------------------------
// startIndex [SinkInt]
// Copies the data at the input pin and stores it in an internal buffer

#define AWE_startIndex_ID 30011

// int value[1] - Captured values
#define AWE_startIndex_value_OFFSET 8
#define AWE_startIndex_value_MASK 0x00000100
#define AWE_startIndex_value_SIZE 1


// ----------------------------------------------------------------------
// numTriggers [RunningStatistics]
// Computes long term statistics

#define AWE_numTriggers_ID 30013

// int statisticsType - Type of statistics needed.
// Default value: 3
// Range: 0 to 8
#define AWE_numTriggers_statisticsType_OFFSET 8
#define AWE_numTriggers_statisticsType_MASK 0x00000100
#define AWE_numTriggers_statisticsType_SIZE -1

// float value - Instantaneous output value.
#define AWE_numTriggers_value_OFFSET 9
#define AWE_numTriggers_value_MASK 0x00000200
#define AWE_numTriggers_value_SIZE -1

// float mean - State variable for mean.
#define AWE_numTriggers_mean_OFFSET 10
#define AWE_numTriggers_mean_MASK 0x00000400
#define AWE_numTriggers_mean_SIZE -1

// float avgEnergy - State variable for average energy.
#define AWE_numTriggers_avgEnergy_OFFSET 11
#define AWE_numTriggers_avgEnergy_MASK 0x00000800
#define AWE_numTriggers_avgEnergy_SIZE -1

// int numBlocksProcessed - Counter for the number of blocks processed.
#define AWE_numTriggers_numBlocksProcessed_OFFSET 12
#define AWE_numTriggers_numBlocksProcessed_MASK 0x00001000
#define AWE_numTriggers_numBlocksProcessed_SIZE -1

// int reset - Used to identify the first block which is processed.
#define AWE_numTriggers_reset_OFFSET 13
#define AWE_numTriggers_reset_MASK 0x00002000
#define AWE_numTriggers_reset_SIZE -1


// ----------------------------------------------------------------------
// awb_vinfo [SourceInt]
// Source buffer holding 1 wire of integer data

#define AWE_awb_vinfo_ID 32767

// int value[4] - Array of interleaved audio data
// Default value:
//     1
//     2
//     2
//     4
// Range: unrestricted
#define AWE_awb_vinfo_value_OFFSET 8
#define AWE_awb_vinfo_value_MASK 0x00000100
#define AWE_awb_vinfo_value_SIZE 4


// ----------------------------------------------------------------------
// VR_State [SourceInt]
// Source buffer holding 1 wire of integer data

#define AWE_VR_State_ID 30006

// int value[1] - Array of interleaved audio data
// Default value:
//     0
// Range: unrestricted
#define AWE_VR_State_value_OFFSET 8
#define AWE_VR_State_value_MASK 0x00000100
#define AWE_VR_State_value_SIZE 1


// ----------------------------------------------------------------------
// PortAudio_Status [SourceInt]
// Source buffer holding 1 wire of integer data

#define AWE_PortAudio_Status_ID 30007

// int value[1] - Array of interleaved audio data
// Default value:
//     0
// Range: unrestricted
#define AWE_PortAudio_Status_value_OFFSET 8
#define AWE_PortAudio_Status_value_MASK 0x00000100
#define AWE_PortAudio_Status_value_SIZE 1


// ----------------------------------------------------------------------
// PortAudio_CPU_Load [Source]
// Source buffer holding 1 wire of data

#define AWE_PortAudio_CPU_Load_ID 30008

// float value[1] - Array of interleaved audio data.
// Default value:
//     0
// Range: unrestricted
#define AWE_PortAudio_CPU_Load_value_OFFSET 8
#define AWE_PortAudio_CPU_Load_value_MASK 0x00000100
#define AWE_PortAudio_CPU_Load_value_SIZE 1



#endif // VOICEUI_IMX8_2MIC_AVS_V3B_1MB_SENSORY_AWELIBSIMPLE_H

